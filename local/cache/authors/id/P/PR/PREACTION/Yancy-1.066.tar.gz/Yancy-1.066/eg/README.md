
# Yancy Examples

These are example Yancy sites. Feel free to copy any of the code inside
for your own site!

If you have any questions, join us on IRC at
<https://kiwiirc.com/nextclient/#irc://irc.freenode.org/#mojo-yancy?nick=yancy-guest-?>.

